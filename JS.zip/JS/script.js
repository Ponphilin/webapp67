console.log("hello javascript");
console.log("สวัสดีวันพุธ"); /*ผลลัพธ์ใน Console */
document.getElementById("text").innerHTML = "Ponphilin Channgarm"; /*เรียกใช้ ID ชื่อ Text*/
window.alert("welcome to my page"); /*แสดงหน้าต่างแจ้งเตือน*/